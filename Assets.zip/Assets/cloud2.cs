using UnityEngine;

public class CloudController : MonoBehaviour
{
    public float growSpeed = 0.1f; // Adjust this value to control the speed at which the cloud grows
    public float shrinkSpeed = 0.1f; // Adjust this value to control the speed at which the cloud shrinks
    public float growDuration = 3f; // Duration for the cloud to grow (in seconds)

    private Vector3 initialScale;
    private bool isGrowing = true;
    private float elapsedTime = 0f;

    void Start()
    {
        // Store the initial scale of the cloud
        initialScale = transform.localScale;
    }

    void Update()
    {
        if (isGrowing)
        {
            Grow();
        }
        else
        {
            Shrink();
        }
    }

    void Grow()
    {
        // Increase the scale of the cloud gradually
        transform.localScale += Vector3.one * growSpeed * Time.deltaTime;

        // Check if the grow duration has elapsed
        elapsedTime += Time.deltaTime;
        if (elapsedTime >= growDuration)
        {
            isGrowing = false;
            elapsedTime = 0f;
        }
    }

    void Shrink()
    {
        // Decrease the scale of the cloud gradually
        transform.localScale -= Vector3.one * shrinkSpeed * Time.deltaTime;

        // Make sure the cloud doesn't shrink below its initial scale
        transform.localScale = Vector3.Max(transform.localScale, initialScale);
    }
}
