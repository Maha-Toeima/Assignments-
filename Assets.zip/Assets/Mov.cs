using UnityEngine;

public class SquidJump : MonoBehaviour
{
    public float jumpForce = 10f; // The force applied to make the squid jump
    public float fallMultiplier = 2.5f; // Multiplier for faster falling
    public float lowJumpMultiplier = 2f; // Multiplier for lower jump

    private Rigidbody2D rb; // Reference to the Rigidbody2D component
    private bool jumped = false; // Flag to track if the squid has jumped

    void Start()
    {
        // Get the reference to the Rigidbody2D component attached to the squid
        rb = GetComponent<Rigidbody2D>();
        
        // Check if Rigidbody2D is attached
        if(rb == null)
        {
            Debug.LogError("Rigidbody2D component is missing on Squid_Animations GameObject.");
            return;
        }

        // Call the Jump method when the game starts
        Jump();
    }

    void Update()
    {
        // Check if the squid has jumped and is currently falling
        if (jumped && rb.velocity.y < 0)
        {
            // Apply stronger gravity when falling for a faster descent
            rb.velocity += Vector2.up * Physics2D.gravity.y * (fallMultiplier - 1) * Time.deltaTime;
        }
        // Check if the squid has jumped and is still ascending
        else if (jumped && rb.velocity.y > 0)
        {
            // Apply lower jump when releasing the jump key early
            rb.velocity += Vector2.up * Physics2D.gravity.y * (lowJumpMultiplier - 1) * Time.deltaTime;
        }
    }

    void Jump()
    {
        // Apply the upward jump force
        rb.velocity = new Vector2(rb.velocity.x, 0f); // Reset y velocity
        rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);

        // Set the jumped flag to true
        jumped = true;
    }
}

