using UnityEngine;

public class AlignCameraToObject : MonoBehaviour
{
    public Transform targetObject; // Reference to the object you want to align the camera with

    void Start()
    {
        // Check if the target object is assigned
        if (targetObject != null)
        {
            // Align the camera's position and rotation with the target object
            transform.position = targetObject.position;
            transform.rotation = targetObject.rotation;

            // Debug log to check alignment
            Debug.Log("Camera aligned with object. Position: " + transform.position + ", Rotation: " + transform.rotation.eulerAngles);
        }
        else
        {
            Debug.LogWarning("Target object is not assigned.");
        }
    }
}
